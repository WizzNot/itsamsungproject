package com.example.project.main;
import com.example.project.util.Elemensall;

public interface SelectListener {
    void onItemClicked(Elemensall element);
}
