package com.example.project;

import android.app.Application;
import android.util.Log;

import com.vk.api.sdk.utils.VKUtils;

import java.util.Arrays;

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
